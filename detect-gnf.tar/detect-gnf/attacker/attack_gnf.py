from scapy.all import sniff, Raw

def packet_callback(packet):
    if packet.haslayer(Raw):
        payload = packet[Raw].load.decode(errors="ignore")  # decode safely
        print("[DEBUG] Sniffed payload:", payload)

        if "USER" in payload or "PASS" in payload:
            print("[+] Captured FTP credentials:", payload.strip())
        elif "STOR" in payload or "RETR" in payload:
            print("[+] FTP file transfer command detected:", payload.strip())

        
        with open("log.txt", "a") as log_file:
            log_file.write(payload.strip() + "\n")

if __name__ == "__main__":
    print("[*] Starting FTP sniffing on port 21...")
    try:
        sniff(filter="tcp port 21", prn=packet_callback, store=0)
    except KeyboardInterrupt:
        print("\n[*] Sniffing stopped.")
