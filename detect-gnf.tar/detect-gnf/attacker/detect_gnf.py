import argparse
import math
from collections import Counter

GNF_WORDS = {"hello", "hi", "friend", "you", "everyone", "world"}

def calc_entropy(text):
    freqs = Counter(text)
    total = len(text)
    return -sum((count / total) * math.log2(count / total) for count in freqs.values()) if total > 0 else 0

def repetition_ratio(text):
    words = text.split()
    return 1 - len(set(words)) / len(words) if words else 0

def has_punctuation(text):
    return any(p in text for p in ['.', '?', '!', ','])

def match_gnf_words(text, gnf_word_set):
    words = set(text.split())
    overlap = words & gnf_word_set
    return len(overlap) / len(words) if words else 0

def detect_stego(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()
    words = text.split()
    word_count = len(words)

    print("="*40)
    print(f"📄 Analyzing file: {filepath}")
    print(f"Total words: {word_count}")

    if word_count < 5:
        print("⚠️ Warning: Very short message. Results may be unreliable.")

    entropy = calc_entropy(text)
    repeat_ratio = repetition_ratio(text)
    punct = has_punctuation(text)
    gnf_match = match_gnf_words(text, GNF_WORDS)

    print(f"Entropy: {entropy:.2f} {'⚠️' if entropy < 4.0 else ''}")
    print(f"Word repetition ratio: {repeat_ratio:.2f} {'⚠️' if repeat_ratio > 0.4 else ''}")
    print(f"Punctuation present: {'Yes' if punct else 'No'} {'⚠️' if not punct else ''}")
    print(f"GNF word match ratio: {gnf_match:.2f} {'⚠️' if gnf_match > 0.5 else ''}")
    print("="*40)

    warnings = sum([
        entropy < 4.0,
        repeat_ratio > 0.4,
        not punct,
        gnf_match > 0.5
    ])

    if warnings >= 2:
        print(" WARNING: This file is likely to contain GNF steganography!")
    else:
        print(" No significant steganographic signs detected.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Detect GNF steganography in text files.")
    parser.add_argument("-m", "--message", required=True, help="Path to message file to analyze")
    args = parser.parse_args()
    detect_stego(args.message)
