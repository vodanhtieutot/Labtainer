import argparse

# GNF Rules embedded directly
GNF_RULES = {
    "S": { "0": "hello A", "1": "hi B" },
    "A": { "0": "world", "1": "friend" },
    "B": { "0": "everyone", "1": "you" }
}

# Decode GNF-based text back to bits
def reverse_gnf(text, rules):
    words = text.strip().split()
    current_symbol = 'S'
    bits = ''
    for i in range(len(words)-1):
        found = False
        for bit in ['0', '1']:
            rule = rules.get(current_symbol, {}).get(bit)
            if rule and rule.split()[0] == words[i]:
                current_symbol = rule.split()[1] if len(rule.split()) > 1 else None
                bits += bit
                found = True
                break
        if not found:
            break
    return bits

# CLI
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Decode a GNF-encoded message.")
    parser.add_argument("-f", "--file", required=True, help="File with encoded message")
    args = parser.parse_args()

    with open(args.file, "r") as f:
        encoded_text = f.read()

    bits = reverse_gnf(encoded_text, GNF_RULES)
    message = ''.join(chr(int(bits[i:i+8], 2)) for i in range(0, len(bits), 8))
    print("[+] Decoded message:", message)
