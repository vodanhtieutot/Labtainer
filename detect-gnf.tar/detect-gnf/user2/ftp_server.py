from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
import os

# === GNF RULES ===
GNF_RULES = {
    "S": { "0": "hello A", "1": "hi B" },
    "A": { "0": "world", "1": "friend" },
    "B": { "0": "everyone", "1": "you" }
}

# === Decode logic ===
def reverse_gnf(text, rules):
    words = text.strip().split()
    current_symbol = 'S'
    bits = ''
    for i in range(len(words)-1):
        found = False
        for bit in ['0', '1']:
            rule = rules.get(current_symbol, {}).get(bit)
            if rule and rule.split()[0] == words[i]:
                current_symbol = rule.split()[1] if len(rule.split()) > 1 else None
                bits += bit
                found = True
                break
        if not found:
            break
    return bits

# === Custom FTP handler ===
class MyHandler(FTPHandler):
    def on_file_received(self, file):
        if file.endswith("message.txt"):
            print(f"[*] File received: {file}")
            try:
                with open(file, 'r') as f:
                    encoded = f.read()
                bits = reverse_gnf(encoded, GNF_RULES)
                message = ''.join(chr(int(bits[i:i+8], 2)) for i in range(0, len(bits), 8))
                print("[+] Decoded message:", message)
            except Exception as e:
                print("[!] Failed to decode:", e)

# === Setup upload folder ===
UPLOAD_DIR = os.path.join(os.getcwd(), "ftp_upload")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# === Setup user ===
authorizer = DummyAuthorizer()
authorizer.add_user("user", "123456", UPLOAD_DIR, perm="elradfmw")  # full access

handler = MyHandler
handler.authorizer = authorizer

# === Run FTP server ===
server = FTPServer(("0.0.0.0", 21), handler)
print(f"[+] FTP server running on port 21. Upload folder: {UPLOAD_DIR}")
server.serve_forever()
