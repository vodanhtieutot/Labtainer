import argparse
import json

# GNF Rules embedded directly
GNF_RULES = {
    "S": { "0": "hello A", "1": "hi B" },
    "A": { "0": "world", "1": "friend" },
    "B": { "0": "everyone", "1": "you" }
}

# Encode bits to text using GNF
def encode_message(bits, rules):
    output = ""
    current_symbol = 'S'
    for bit in bits:
        rule = rules.get(current_symbol)
        if not rule or bit not in rule:
            raise ValueError(f"No rule for {current_symbol} with bit {bit}")
        production = rule[bit]
        tokens = production.split()
        output += tokens[0] + " "
        current_symbol = tokens[1] if len(tokens) > 1 else None
        if current_symbol is None:
            break
    return output.strip()

# CLI
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Encode a message using GNF steganography.")
    parser.add_argument("-m", "--message", required=True, help="Message to encode")
    args = parser.parse_args()

    bits = ''.join(f"{ord(c):08b}" for c in args.message)
    encoded = encode_message(bits, GNF_RULES)

    with open("message.txt", "w") as f:
        f.write(encoded)

    print("[+] Encoded message saved to message.txt")
