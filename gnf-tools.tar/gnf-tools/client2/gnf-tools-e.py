import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from gnf_utils import load_gnf_rules

def extract_bits(text, rules):
    words = text.split()
    bits = []
    current_symbol = 'S'
    i = 0
    while i < len(words) and current_symbol:
        rule = rules.get(current_symbol)
        if not rule:
            break
        for bit, production in rule.items():
            tokens = production.split()
            if tokens and tokens[0] == words[i]:
                bits.append(bit)
                current_symbol = tokens[1] if len(tokens) > 1 else None
                break
        i += 1
    return ''.join(bits)

def bits_to_string(bit_str):
    chars = []
    for i in range(0, len(bit_str), 8):
        byte = bit_str[i:i+8]
        if len(byte) == 8:
            chars.append(chr(int(byte, 2)))
    return ''.join(chars)

def browse_file():
    filepath = filedialog.askopenfilename(title="Select gnf_rules.cfg", filetypes=[("CFG files", "*.cfg")])
    if filepath:
        cfg_entry.delete(0, tk.END)
        cfg_entry.insert(0, filepath)

def handle_extract():
    sentence = sentence_entry.get().strip()
    cfg_path = cfg_entry.get().strip()
    if not sentence:
        messagebox.showwarning("Warning", "Please enter an encoded sentence.")
        return
    if not cfg_path:
        messagebox.showwarning("Warning", "Please select gnf_rules.cfg.")
        return
    try:
        rules = load_gnf_rules(cfg_path)
        bits = extract_bits(sentence, rules)
        decoded = bits_to_string(bits)
        with open("decoded.txt", "w") as f:
            f.write(decoded)
        result_label.config(text=f"✅ Decoded message saved to 'decoded.txt'\n\n{decoded}")
    except Exception as e:
        messagebox.showerror("Decoding Error", str(e))

def handle_clear():
    sentence_entry.delete(0, tk.END)
    cfg_entry.delete(0, tk.END)
    result_label.config(text="")

root = tk.Tk()
root.title("GNF Stego – Extract")
root.geometry("700x320")

ttk.Label(root, text="Enter encoded sentence:").pack(pady=5)
sentence_entry = ttk.Entry(root, width=80)
sentence_entry.pack()

frame = ttk.Frame(root)
frame.pack(pady=5)
cfg_entry = ttk.Entry(frame, width=50)
cfg_entry.pack(side="left")
ttk.Button(frame, text="Browse…", command=browse_file).pack(side="left", padx=5)

ttk.Button(root, text="Extract", command=handle_extract).pack(pady=10)

result_label = ttk.Label(root, text="", font=("Segoe UI", 10), wraplength=600, justify="center")
result_label.pack()

ttk.Button(root, text="Clear", command=handle_clear).pack(pady=5)

root.mainloop()
