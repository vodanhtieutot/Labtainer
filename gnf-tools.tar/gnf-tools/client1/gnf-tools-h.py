import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from gnf_utils import load_gnf_rules

def string_to_bits(s):
    return ''.join(f"{ord(c):08b}" for c in s)

def hide_message(bits, rules):
    output = ""
    current_symbol = 'S'
    for bit in bits:
        rule = rules.get(current_symbol)
        if not rule or bit not in rule:
            raise ValueError(f"No rule for {current_symbol} with bit {bit}")
        production = rule[bit]
        tokens = production.split()
        output += tokens[0] + " "
        current_symbol = tokens[1] if len(tokens) > 1 else None
        if current_symbol is None:
            break
    return output.strip()

def browse_file():
    filepath = filedialog.askopenfilename(title="Select gnf_rules.cfg", filetypes=[("CFG files", "*.cfg")])
    if filepath:
        cfg_entry.delete(0, tk.END)
        cfg_entry.insert(0, filepath)

def handle_hide():
    text = input_entry.get().strip()
    cfg_path = cfg_entry.get().strip()
    if len(text) == 0 or len(text) > 4:
        messagebox.showerror("Error", "Please enter 1 to 4 characters.")
        return
    if not cfg_path:
        messagebox.showerror("Error", "Please select gnf_rules.cfg.")
        return
    try:
        rules = load_gnf_rules(cfg_path)
        bits = string_to_bits(text)
        encoded = hide_message(bits, rules)
        with open("message.txt", "w") as f:
            f.write(encoded)
        result_label.config(text=f"✅ Encoded message saved to 'message.txt'\n\n{encoded}")
    except Exception as e:
        messagebox.showerror("Encoding Error", str(e))

def handle_clear():
    input_entry.delete(0, tk.END)
    cfg_entry.delete(0, tk.END)
    result_label.config(text="")

root = tk.Tk()
root.title("GNF Stego – Hide")
root.geometry("700x320")

ttk.Label(root, text="Enter 1–4 characters:").pack(pady=5)
input_entry = ttk.Entry(root, width=40)
input_entry.pack()

frame = ttk.Frame(root)
frame.pack(pady=5)
cfg_entry = ttk.Entry(frame, width=50)
cfg_entry.pack(side="left")
ttk.Button(frame, text="Browse…", command=browse_file).pack(side="left", padx=5)

ttk.Button(root, text="Hide", command=handle_hide).pack(pady=10)

result_label = ttk.Label(root, text="", font=("Segoe UI", 10), wraplength=600, justify="center")
result_label.pack()

ttk.Button(root, text="Clear", command=handle_clear).pack(pady=5)

root.mainloop()
