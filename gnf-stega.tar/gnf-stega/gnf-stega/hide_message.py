# hide_message.py

from gnf_utils import load_gnf_rules

def hide_message(bits, rules):
    output = ""
    current_symbol = 'S'
    for bit in bits:
        rule = rules.get(current_symbol)
        if not rule or bit not in rule:
            raise ValueError(f"No rule for {current_symbol} with bit {bit}")
        production = rule[bit]
        tokens = production.split()
        output += tokens[0] + " "
        current_symbol = tokens[1] if len(tokens) > 1 else None
        if current_symbol is None:
            break
    return output.strip()

if __name__ == "__main__":
    rules = load_gnf_rules("gnf_rules.cfg")

    # Step 1: Read binary string from file
    try:
        with open("binary.txt", "r") as f:
            binary_input = f.read().strip()
    except FileNotFoundError:
        raise FileNotFoundError("❌ File 'binary.txt' not found. Please generate it first using gnf_utils.")

    # Step 2: Validate binary content
    if not binary_input or not all(c in "01" for c in binary_input):
        raise ValueError("❌ 'binary.txt' must contain a valid binary string (only 0s and 1s).")

    print(f"📥 Read binary input ({len(binary_input)} bits): {binary_input}")

    # Step 3: Encode
    encoded_text = hide_message(binary_input, rules)

    # Step 4: Write output
    with open("message.txt", "w") as f:
        f.write(encoded_text)

    print(f" Encoded sentence written to 'message.txt':\n{encoded_text}")
