def load_gnf_rules(filename):
    rules = {}
    current_key = None
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("[") and line.endswith("]"):
                current_key = line[1:-1]
                rules[current_key] = {}
            elif "=" in line and current_key:
                bit, production = line.split("=", 1)
                rules[current_key][bit.strip()] = production.strip()
    return rules

def extract_bits(text, rules):
    words = text.split()
    bits = []
    current_symbol = 'S'
    i = 0
    while i < len(words) and current_symbol:
        rule = rules.get(current_symbol)
        if not rule:
            break
        for bit, production in rule.items():
            tokens = production.split()
            if tokens and tokens[0] == words[i]:
                bits.append(bit)
                current_symbol = tokens[1] if len(tokens) > 1 else None
                break
        i += 1
    return ''.join(bits)

def bits_to_string(bit_str):
    if len(bit_str) % 8 != 0:
        print("Warning: Bit length is not a multiple of 8. Padding may be incorrect.")
    chars = []
    for i in range(0, len(bit_str), 8):
        byte = bit_str[i:i+8]
        if len(byte) == 8:
            chars.append(chr(int(byte, 2)))
    return ''.join(chars)

if __name__ == "__main__":
    rules = load_gnf_rules("gnf_rules.cfg")
    sentence = input("Enter the encoded sentence: ").strip()

    bits = extract_bits(sentence, rules)
    print(f"Extracted binary: {bits} ({len(bits)} bits)")

    decoded = bits_to_string(bits)
    print(f"Decoded string: {decoded}")
