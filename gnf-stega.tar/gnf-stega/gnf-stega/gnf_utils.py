# gnf_utils.py

def load_gnf_rules(filename):
    rules = {}
    current_key = None
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("[") and line.endswith("]"):
                current_key = line[1:-1]
                rules[current_key] = {}
            elif "=" in line and current_key:
                bit, production = line.split("=", 1)
                rules[current_key][bit.strip()] = production.strip()
    return rules

def string_to_bits_interactive(output_file="binary.txt"):
    user_input = input("Enter 1 to 4 characters to hide: ").strip()
    if len(user_input) == 0 or len(user_input) > 4:
        raise ValueError("Input must be between 1 and 4 characters.")
    
    bit_string = ''.join(f"{ord(c):08b}" for c in user_input)
    
    with open(output_file, "w") as f:
        f.write(bit_string)

    print(f" Binary representation saved to {output_file}: {bit_string} ({len(bit_string)} bits)")
    return bit_string


if __name__ == "__main__":
    string_to_bits_interactive()
